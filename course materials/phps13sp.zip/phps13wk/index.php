   <?php # index.php
   // This is the main page for the site.

   // Set the page title and include the HMTL header.

   $page_title = 'Content Management Site';
   include ('./includes/header.html');
   ?>

   	<p>Spam spam spam spam spam spam spam
   	spam spam spam spam spam spam spam spam
   	spam spam spam spam spam spam spam spam spam.</p>

   	<p>Spam spam spam spam spam spam spam
   	spam spam spam spam spam spam spam spam
   	spam spam spam spam spam spam spam spam spam.</p> 

  <?php
   include ('./includes/footer.html');
   ?>
